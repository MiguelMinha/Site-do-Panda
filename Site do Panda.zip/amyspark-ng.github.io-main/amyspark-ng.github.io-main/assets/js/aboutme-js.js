function copyDiscord() {
	navigator.clipboard.writeText("AmyGaming_#6705");
	
	alert("Copied! - AmyGaming_#6705")
}